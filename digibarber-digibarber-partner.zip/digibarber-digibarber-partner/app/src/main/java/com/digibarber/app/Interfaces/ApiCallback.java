package com.digibarber.app.Interfaces;

public interface ApiCallback {
    void onSuccess();
    void onFailure();
}
