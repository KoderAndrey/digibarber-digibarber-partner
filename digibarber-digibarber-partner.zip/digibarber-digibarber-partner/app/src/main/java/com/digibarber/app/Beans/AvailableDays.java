package com.digibarber.app.Beans;

/**
 * Created by DIGIBARBER LTD on 3/10/17.
 */

public class AvailableDays {

    public String date;
    public  String is_day_on;


    public  AvailableDays()
    {

    }

}
