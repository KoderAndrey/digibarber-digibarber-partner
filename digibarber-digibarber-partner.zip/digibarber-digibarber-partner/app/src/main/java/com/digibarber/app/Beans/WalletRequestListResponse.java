package com.digibarber.app.Beans;

import java.io.Serializable;

/**
 * Created by DIGIBARBER LTD on 3/10/17.
 */

public class WalletRequestListResponse implements Serializable
{
    public  String deduct_amount = "";
    public  String booking_id = "";
    public  String price = "";
    public String is_confirmed = "";
    public String booking_date = "";
    public String transaction_id = "";
    public  String service_name = "";
}
