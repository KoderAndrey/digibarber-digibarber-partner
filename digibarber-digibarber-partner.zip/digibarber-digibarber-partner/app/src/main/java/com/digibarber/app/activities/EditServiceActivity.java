package com.digibarber.app.activities;

import android.os.Bundle;

import com.digibarber.app.CustomClasses.BaseActivity;
import com.digibarber.app.R;

public class EditServiceActivity extends BaseActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_service);
    }


}
