package com.digibarber.app.Interfaces;

/**
 * Created by DIGIBARBER LTD on 19/7/17.
 */
public interface SelectServiceListener {


    void onServiceSelcted(int subserviceposition, int listpos);

}
