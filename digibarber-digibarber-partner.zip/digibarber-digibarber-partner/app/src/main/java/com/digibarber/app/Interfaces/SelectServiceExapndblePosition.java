package com.digibarber.app.Interfaces;

/**
 * Created by DIGIBARBER LTD on 25/9/17.
 */

public interface SelectServiceExapndblePosition {


    void onDesSelcted(int group, int child);
}
