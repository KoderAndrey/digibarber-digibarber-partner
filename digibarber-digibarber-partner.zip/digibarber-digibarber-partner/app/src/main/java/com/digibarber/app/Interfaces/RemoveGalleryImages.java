package com.digibarber.app.Interfaces;

/**
 * Created by DIGIBARBER LTD on 22/10/17.
 */

public interface RemoveGalleryImages {

    void RemoveGalleryImages(int pos);
    void ReplaceGalleryImages(int pos);
}
