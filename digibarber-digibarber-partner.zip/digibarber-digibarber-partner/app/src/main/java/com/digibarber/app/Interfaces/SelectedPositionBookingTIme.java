package com.digibarber.app.Interfaces;

/**
 * Created by DIGIBARBER LTD on 29/7/17.
 */
public interface SelectedPositionBookingTIme {


    void SelectedPos(int selectedPos, String isConfirmation);


}
