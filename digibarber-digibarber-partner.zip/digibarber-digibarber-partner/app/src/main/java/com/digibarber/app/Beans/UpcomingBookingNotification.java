package com.digibarber.app.Beans;

import java.io.Serializable;

/**
 * Created by DIGIBARBER LTD on 28/8/17.
 */
public class UpcomingBookingNotification implements Serializable {

    public String msg;
    public String date;
    public String dates;
    public String image;
    public String reason;
    public String booking_date;
    public String service_name;
    public String booking_time;
    public String type;
    public String is_read;
    public String booking_id;
    public String new_time;
    public String barber_id;
    public String price;
    public String percentage;
    public String name;
    public String id;
    public String time;
    public String workplace;
    public String address;
    public String lon;
    public String lat;

    public UpcomingBookingNotification()
    {





    }



}
