package com.digibarber.app.Beans;

import java.io.Serializable;

/**
 * Created by DIGIBARBER LTD on 4/9/17.
 */
public class CustomGalleryImages implements Serializable {

    public   String images;


    public CustomGalleryImages()
    {

    }

}
