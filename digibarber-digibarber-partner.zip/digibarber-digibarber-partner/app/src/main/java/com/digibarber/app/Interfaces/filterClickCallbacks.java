package com.digibarber.app.Interfaces;

import android.widget.Button;

/**
 * Created by DIGIBARBER LTD on 23/8/17.
 */
public interface filterClickCallbacks {


    public void getClickedPosition(int pos, int selectdViewPos,Button sub_category_button);


}
