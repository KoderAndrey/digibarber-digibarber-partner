package com.digibarber.app.Interfaces;

/**
 * Created by DIGIBARBER LTD on 28/9/17.
 */

public interface EditServiceCallback {

    void callClick(int pos);

}
