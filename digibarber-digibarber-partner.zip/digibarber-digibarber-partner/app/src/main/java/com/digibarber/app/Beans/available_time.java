package com.digibarber.app.Beans;

/**
 * Created by DIGIBARBER LTD on 4/10/17.
 */

public class available_time {
    public String time;
    public String status;

    public available_time(String time, String status) {
        this.time = time;
        this.status=status;
    }
}
