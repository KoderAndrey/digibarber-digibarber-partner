package com.digibarber.app.Interfaces;

/**
 * Created by DIGIBARBER LTD on 30/9/17.
 */

public interface CalenderListCallbacks {


    void onclickAction(int pos);



}
