package com.digibarber.app.Interfaces;

/**
 * Created by DIGIBARBER LTD on 26/10/17.
 */

public interface InnerNotificationClickCallback {


    void notificationClickListerner(int pos);

}
