package com.digibarber.app.Beans;

import java.io.Serializable;

/**
 * Created by DIGIBARBER LTD on 29/9/17.
 */

public class BookingListDayWise implements Serializable {

    public String date;
    public String date_time;
    public  String is_day_on;
    public  String service_name;
    public   String booking_id;
    public String user_id;
    public  String is_confirmed;
    public  String user_name;
    public String booking_time;
    public  String services;
    public  String is_reschedule;
    public  String isEnableDisable;
    public BookingListDayWise()
    {

    }

}
