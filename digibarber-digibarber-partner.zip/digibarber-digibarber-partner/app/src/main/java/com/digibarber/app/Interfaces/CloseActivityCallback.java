package com.digibarber.app.Interfaces;

/**
 * Created by DIGIBARBER LTD on 27/9/17.
 */

public interface CloseActivityCallback {

    void callFinishActivty();
}
