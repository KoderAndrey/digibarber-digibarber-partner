package com.digibarber.app.Beans;

import java.io.Serializable;

/**
 * Created by DIGIBARBER LTD on 29/8/17.
 */
public class PreviousBooking implements Serializable{


    public String reason="";
    public String address = "";
    public String is_confirmed = "";
    public String booking_time = "";
    public String lon = "";
    public String services = "";
    public String open_hours="";
    public String booking_id = "";
    public String profile_image = "";
    public String barber_id = "";
    public String barber_name = "";
    public String workplace = "";
    public String lat = "";
    public String date = "";
    public String service_name = "";
    public PreviousBooking() {

    }

}
